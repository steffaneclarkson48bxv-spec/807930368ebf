// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Compile render graph");
  std::fflush(stdout);
  return lionss_run_workload("renderGraph");
}
