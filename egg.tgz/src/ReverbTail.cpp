// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render reverb tail"); }
int main(){
  announce();
  return lionss_run_workload("ReverbTail");
}
