// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Inject latency fault"); }
int main(){
  announce();
  return lionss_run_workload("chaoslatency");
}
