// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Propagate orbit\n", stdout);
  return lionss_run_workload("orbit-propagate");
}
