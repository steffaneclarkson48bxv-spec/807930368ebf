// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run integration suite\n", stdout);
  return lionss_run_workload("tungsten");
}
